declare namespace MyGame {
    import ƒ = FudgeCore;
    class Background extends ƒ.Node {
        private static mesh;
        constructor(image: ƒ.TextureImage, dist: number);
    }
}
